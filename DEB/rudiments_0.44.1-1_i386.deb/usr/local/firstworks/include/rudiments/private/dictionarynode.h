// Copyright (c) 2003 David Muse
// See the COPYING file for more information

	protected:
		keytype		key;
		valuetype	value;
