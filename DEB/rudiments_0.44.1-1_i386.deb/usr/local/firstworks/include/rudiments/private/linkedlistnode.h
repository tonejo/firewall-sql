// Copyright (c) 2003 David Muse
// See the COPYING file for more information

	protected:
		valuetype			value;
		linkedlistnode<valuetype>	*next;
		linkedlistnode<valuetype>	*previous;
