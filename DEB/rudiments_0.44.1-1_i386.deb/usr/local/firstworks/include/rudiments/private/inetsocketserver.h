// Copyright (c) 2002 David Muse
// See the COPYING file for more information.

	private:
		inetsocketserverprivate	*pvt;
