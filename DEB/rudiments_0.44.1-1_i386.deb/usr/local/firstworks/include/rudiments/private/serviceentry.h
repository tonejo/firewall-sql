// Copyright (c) 2003 David Muse
// See the COPYING file for more information.

	private:
		bool	initialize(const char *servicename, int32_t port,
							const char *protocol);
		serviceentryprivate	*pvt;
