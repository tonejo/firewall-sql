// Copyright (c) 2012 David Muse
// See the COPYING file for more information.

#include <rudiments/xmldom.h>
#include <rudiments/stringbuffer.h>
